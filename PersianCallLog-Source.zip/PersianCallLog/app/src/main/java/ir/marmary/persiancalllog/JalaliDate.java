package ir.marmary.persiancalllog;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class JalaliDate {
    private JalaliDate() { }
    public static String formatDate(long millis) {
        Calendar c = Calendar.getInstance(); c.setTime(new Date(millis));
        int[] j = gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH));
        return digits(String.format(Locale.US, "%04d/%02d/%02d", j[0],j[1],j[2]));
    }
    public static int[] gregorianToJalali(int gy, int gm, int gd) {
        int[] gdm = {0,31,((gy%4==0 && gy%100!=0)||gy%400==0)?29:28,31,30,31,30,31,31,30,31,30,31};
        int gy2 = gm > 2 ? gy + 1 : gy;
        int days = 355666 + 365*gy + (gy2+3)/4 - (gy2+99)/100 + (gy2+399)/400 + gd;
        for (int i=1; i<gm; i++) days += gdm[i];
        int jy = -1595 + 33*(days/12053); days %= 12053;
        jy += 4*(days/1461); days %= 1461;
        if (days > 365) { jy += (days-1)/365; days = (days-1)%365; }
        int jm, jd;
        if (days < 186) { jm = 1 + days/31; jd = 1 + days%31; }
        else { jm = 7 + (days-186)/30; jd = 1 + (days-186)%30; }
        return new int[]{jy,jm,jd};
    }
    private static String digits(String s) {
        char[] fa={'۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'}; StringBuilder b=new StringBuilder();
        for (char ch:s.toCharArray()) b.append(ch>='0'&&ch<='9'?fa[ch-'0']:ch);
        return b.toString();
    }
}
