package ir.marmary.persiancalllog;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.CallLog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CALL_LOG = 501;
    private LinearLayout listContainer;
    private TextView status;
    private Spinner filterSpinner;
    private final ArrayList<CallItem> allCalls = new ArrayList<>();

    static class CallItem {
        String name, number, date, time, type, duration;
        int callType;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) loadCalls();
        else requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG}, REQUEST_CALL_LOG);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(18));
        root.setBackgroundColor(Color.rgb(245,247,250));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("گزارش تماس شمسی"); title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(25,65,110)); title.setGravity(Gravity.CENTER);
        title.setPadding(0,dp(10),0,dp(14)); root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("تماس‌های ورودی، خروجی و ازدست‌رفته با تاریخ جلالی");
        subtitle.setTextSize(13); subtitle.setTextColor(Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,0,0,dp(14)); root.addView(subtitle);

        filterSpinner = new Spinner(this);
        String[] options = {"همه تماس‌ها", "تماس‌های ورودی", "تماس‌های خروجی", "تماس‌های ازدست‌رفته"};
        filterSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options));
        root.addView(filterSpinner);
        filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { renderCalls(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        status = new TextView(this); status.setText("در حال خواندن گزارش تماس‌ها...");
        status.setTextSize(14); status.setTextColor(Color.GRAY); status.setGravity(Gravity.CENTER);
        status.setPadding(0,dp(12),0,dp(8)); root.addView(status);
        listContainer = new LinearLayout(this); listContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(listContainer, new LinearLayout.LayoutParams(-1,-2));
        Button refresh = new Button(this); refresh.setText("به‌روزرسانی"); refresh.setOnClickListener(v -> loadCalls());
        root.addView(refresh, new LinearLayout.LayoutParams(-1,-2));
        setContentView(scroll);
    }

    private void loadCalls() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG}, REQUEST_CALL_LOG); return;
        }
        allCalls.clear();
        ContentResolver resolver = getContentResolver();
        String[] projection = {CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE, CallLog.Calls.DURATION};
        try (Cursor cursor = resolver.query(CallLog.Calls.CONTENT_URI, projection, null, null, CallLog.Calls.DATE + " DESC")) {
            if (cursor != null) while (cursor.moveToNext()) {
                CallItem item = new CallItem();
                item.name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME));
                item.number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                long millis = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE));
                item.callType = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));
                long seconds = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                item.date = JalaliDate.formatDate(millis);
                item.time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date(millis));
                item.type = typeLabel(item.callType); item.duration = formatDuration(seconds);
                allCalls.add(item);
            }
            renderCalls();
        } catch (SecurityException e) {
            status.setText("دسترسی به گزارش تماس‌ها داده نشده است.");
        } catch (Exception e) {
            status.setText("خطا در خواندن تماس‌ها.");
        }
    }

    private void renderCalls() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        int selected = filterSpinner == null ? 0 : filterSpinner.getSelectedItemPosition();
        int shown = 0;
        for (CallItem c : allCalls) {
            if (selected == 1 && c.callType != CallLog.Calls.INCOMING_TYPE) continue;
            if (selected == 2 && c.callType != CallLog.Calls.OUTGOING_TYPE) continue;
            if (selected == 3 && c.callType != CallLog.Calls.MISSED_TYPE) continue;
            listContainer.addView(makeCallCard(c)); shown++;
        }
        status.setText("تعداد تماس‌های نمایش‌داده‌شده: " + toPersianDigits(String.valueOf(shown)));
        if (shown == 0) {
            TextView empty = new TextView(this); empty.setText(allCalls.isEmpty() ? "تماسی برای نمایش پیدا نشد یا مجوز داده نشده است." : "تماسی در این دسته وجود ندارد.");
            empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(24),0,dp(24)); listContainer.addView(empty);
        }
    }

    private View makeCallCard(CallItem c) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,-2); params.setMargins(0,0,0,dp(9)); card.setLayoutParams(params); card.setElevation(dp(2));
        TextView name = new TextView(this);
        name.setText(!TextUtils.isEmpty(c.name) ? c.name : (!TextUtils.isEmpty(c.number) ? c.number : "شماره ناشناس"));
        name.setTextSize(17); name.setTypeface(Typeface.DEFAULT,Typeface.BOLD); name.setTextColor(Color.rgb(35,48,65)); name.setGravity(Gravity.RIGHT); card.addView(name);
        TextView info = new TextView(this); info.setText(c.type + "   •   " + c.date + "   •   " + c.time);
        info.setTextSize(13); info.setTextColor(colorForType(c.callType)); info.setGravity(Gravity.RIGHT); info.setPadding(0,dp(6),0,dp(4)); card.addView(info);
        TextView duration = new TextView(this); duration.setText("مدت مکالمه: " + c.duration); duration.setTextSize(12); duration.setTextColor(Color.GRAY); duration.setGravity(Gravity.RIGHT); card.addView(duration);
        return card;
    }

    private String typeLabel(int type) {
        if (type == CallLog.Calls.INCOMING_TYPE) return "ورودی";
        if (type == CallLog.Calls.OUTGOING_TYPE) return "خروجی";
        if (type == CallLog.Calls.MISSED_TYPE) return "ازدست‌رفته";
        if (type == CallLog.Calls.REJECTED_TYPE) return "ردشده";
        if (type == CallLog.Calls.BLOCKED_TYPE) return "مسدودشده";
        return "تماس";
    }
    private int colorForType(int type) {
        if (type == CallLog.Calls.MISSED_TYPE) return Color.rgb(190,45,45);
        if (type == CallLog.Calls.OUTGOING_TYPE) return Color.rgb(30,120,75);
        return Color.rgb(45,95,160);
    }
    private String formatDuration(long seconds) { return toPersianDigits(String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60)); }
    private String toPersianDigits(String s) {
        char[] fa={'۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'}; StringBuilder out=new StringBuilder();
        for (int i=0;i<s.length();i++) { char ch=s.charAt(i); out.append(ch>='0'&&ch<='9'?fa[ch-'0']:ch); }
        return out.toString();
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode==REQUEST_CALL_LOG) {
            if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) loadCalls();
            else status.setText("برای نمایش تماس‌ها، مجوز گزارش تماس‌ها را تأیید کن.");
        }
    }
}
